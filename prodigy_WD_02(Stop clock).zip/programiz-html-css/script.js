let startTime = 0;
let elapsedTime = 0;
let timerInterval;
const display = document.getElementById('display');
const lapsList = document.getElementById('laps');

function updateTime() {
  const time = Date.now() - startTime + elapsedTime;
  const date = new Date(time);
  const minutes = String(date.getUTCMinutes()).padStart(2, '0');
  const seconds = String(date.getUTCSeconds()).padStart(2, '0');
  const milliseconds = String(Math.floor(date.getUTCMilliseconds() / 10)).padStart(2, '0');
  display.textContent = `${minutes}:${seconds}:${milliseconds}`;
}

document.getElementById('start').onclick = function () {
  if (!timerInterval) {
    startTime = Date.now();
    timerInterval = setInterval(updateTime, 10);
  }
};

document.getElementById('pause').onclick = function () {
  if (timerInterval) {
    clearInterval(timerInterval);
    elapsedTime += Date.now() - startTime;
    timerInterval = null;
  }
};

document.getElementById('reset').onclick = function () {
  clearInterval(timerInterval);
  timerInterval = null;
  startTime = 0;
  elapsedTime = 0;
  display.textContent = "00:00:00";
  lapsList.innerHTML = '';
};

document.getElementById('lap').onclick = function () {
  if (timerInterval) {
    const lapItem = document.createElement('li');
    lapItem.textContent = display.textContent;
    lapsList.appendChild(lapItem);
  }
};
